﻿using BusinessLogicsAbstractions;
using Contract;

namespace BusinessLogics;

public class ProductImportService(
    IProductImporterProvider importerProvider,
    IImportedProductCreatorService importedProductCreatorService) : IProductImportService
{
    public List<ProductResponseDto> ImportProducts(ProductImportRequestDto request)
    {
        ValidateRequest(request);

        var importer = FindImporter(request.ImporterName);

        var importedProducts = importer.Import(request.FileStream);

        return importedProducts
            .Select(importedProduct =>
                importedProductCreatorService.CreateImportedProduct(
                    importedProduct))
            .ToList();
    }

    private static void ValidateRequest(ProductImportRequestDto request)
    {
        if(request == null)
        {
            throw new ValidationException(
                "La solicitud de importación es requerida");
        }

        if(string.IsNullOrWhiteSpace(request.ImporterName))
        {
            throw new ValidationException(
                "El nombre del importador es requerido");
        }

        if(request.FileStream == null)
        {
            throw new ValidationException(
                "El archivo de importación es requerido");
        }

        if(string.IsNullOrWhiteSpace(request.FileName))
        {
            throw new ValidationException(
                "El nombre del archivo es requerido");
        }
    }

    private IProductImporter FindImporter(string importerName)
    {
        var importer = importerProvider
            .GetImporters()
            .FirstOrDefault(i => i.Name == importerName);
        if(importer == null)
        {
            throw new NotFoundException($"No existe el importador {importerName}");
        }

        return importer;
    }
}
