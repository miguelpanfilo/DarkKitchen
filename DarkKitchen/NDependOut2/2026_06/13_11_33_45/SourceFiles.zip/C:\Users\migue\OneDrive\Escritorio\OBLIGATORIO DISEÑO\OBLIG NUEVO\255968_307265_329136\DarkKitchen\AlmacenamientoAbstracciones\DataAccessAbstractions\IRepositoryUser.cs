using Domain;

namespace DataAccessAbstractions;

public interface IRepositoryUser
{
    User Add(User user);
    List<User> GetAll();
    bool EmailExist(string email);
    User? FindByEmail(string email);
    User? FindById(int id);
    void Remove(int id);
    User Update(User user);
    User? FindByIdIncludingInactive(int id);
}
